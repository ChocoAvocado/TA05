
<body>
    <h1>Halaman about</h1>
    <p>nama = <?= $data['nama']; ?>, pekerjaan = <?= $data['pekerjaan']; ?>, umur = <?= $data['umur']; ?></p>
</body>
</html>