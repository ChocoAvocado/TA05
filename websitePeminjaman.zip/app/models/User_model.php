<?php

class User_model {
    
}