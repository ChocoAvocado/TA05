<?php
session_start();
require_once '../app/init.php';
// require '../vendor/autoload.php';  buat composer 

$app = new App;