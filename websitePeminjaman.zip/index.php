<?php header("location:public"); ?>
